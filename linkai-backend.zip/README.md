# linkai-backend

Backend com IA emocional para análise de conversas e geração de dicas.